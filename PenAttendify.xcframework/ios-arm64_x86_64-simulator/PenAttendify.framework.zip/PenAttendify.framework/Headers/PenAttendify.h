//
//  PenAttendify.h
//  PenAttendify
//
//  Created by Fawzi Rifai on 23/07/2023.
//

#import <Foundation/Foundation.h>

//! Project version number for PenAttendify.
FOUNDATION_EXPORT double PenAttendifyVersionNumber;

//! Project version string for PenAttendify.
FOUNDATION_EXPORT const unsigned char PenAttendifyVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PenAttendify/PublicHeader.h>


